

bool IsAtCommand(const String& s);
void ServoMotorControl();
void FlipFlopLed();
float GetCentimeterUltrasonic(const Ultrasonic& ult, const bool& isSerialPrint);
bool UltraCentimeterMayActiveMotor(const Ultrasonic& ultra, const bool& isWriteSerial );


